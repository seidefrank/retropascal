/*

  P-Code interpreter (to run the apple pascal system)
  Copyright (C) 2000 Mario Klebsch

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  $Log: Printer.c,v $
  Revision 1.3  2001/06/16 20:25:50  mario
  Syntaxfehler in PrinterClear() behoben.

  Revision 1.2  2001/06/06 23:10:00  mario
  Ausgabe wahlweise �ber das Spool-System oder direkt an ein Device.

  Revision 1.1  2001/05/20 20:14:40  mario
  Neues Ger�t PRINTER: implementiert



*/

#ident "$Id: Printer.c,v 1.3 2001/06/16 20:25:50 mario Exp $";

#include <stdio.h>

#include "psystem.h"
#include "Memory.h"

FILE *Printer=NULL;

void PrinterWrite(byte ch, word Mode)
{
  static int Dle=0;

  if (!Printer)
#ifdef PRINT_DEVICE
    Printer=fopen(PRINT_DEVICE, "w");
#else
    Printer=popen("lp -s", "w");
#endif

  if (!Printer)
    {
    }
  else
    if (!Dle)
      {
	switch(ch)
	  {
	  case 0:
	    if (!(Mode&0x8))
	      return;
	  case 13:			/* carriage return		    */
	    if (!(Mode&0x4))
	      ch='\n';
	    break;
	  case 16:			/* DLE prefix			    */
	    if (!(Mode&0x8))
	      {
		Dle=1;
		return;
	      }
	    break;
	  }
	fputc(ch, Printer);
      }
    else
      {
	ch -= 0x20;
	while (ch--)
	  fputc(' ', Printer);
	Dle=0;
    }
}

void PrinterClear(void)
{
  if (Printer)
    {
#ifdef PRINT_DEVICE
      fclose(Printer);
#else
      pclose(Printer);
#endif
      Printer=NULL;
    }
}
