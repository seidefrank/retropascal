/*

  P-Code interpreter (to run the apple pascal system)
  Copyright (C) 2000 Mario Klebsch

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  $Log: Bin2C.c,v $
  Revision 1.2  2001/05/20 13:12:02  mario
  CVS-Idents und Logs eingef�gt


*/

#ident "$Id: Bin2C.c,v 1.2 2001/05/20 13:12:02 mario Exp $";

#include <stdio.h>
#include <unistd.h>
#include <sys/fcntl.h>

int main(int argc, char *argv[])
{
  int	fd;
  unsigned char	Buffer[16];
  int	Len;
  int	i;
  int	Flag;
  if (argc<2)
    fd=fileno(stdin);
  else if ((fd=open(argv[1], O_RDONLY))<0)
    {
      perror(argv[1]);
      exit(-1);
    }

  Flag=0;
  while ((Len=read(fd, Buffer, sizeof(Buffer)))>0)
    {
      for (i=0;i<Len;i++)
	{
	  if (Flag&1)
	    printf(",");
	  if (Flag&2)
	    {
	      printf("\n");
	      Flag &= ~2;
	    }
	  printf("0x%02x", Buffer[i]);
	  Flag|=1;
	}
      Flag |=2 ;
    }
  close(fd);
  exit(0);
}
