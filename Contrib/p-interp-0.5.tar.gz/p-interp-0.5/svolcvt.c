/*

  P-Code interpreter (to run the apple pascal system)
  Copyright (C) 2000 Mario Klebsch

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


  $Log: svolcvt.c,v $
  Revision 1.3  2001/05/20 13:51:06  mario
  R�ckgabewert 0 in main() eingebaut, man-Page aktualisiert.

  Revision 1.2  2001/05/20 13:12:02  mario
  CVS-Idents und Logs eingef�gt


*/

#ident "$Id: svolcvt.c,v 1.3 2001/05/20 13:51:06 mario Exp $";

#include <stdio.h>
#include <unistd.h>

# define SEC_SIZE	256
# define SEC_PER_TRACK	16
int table[SEC_PER_TRACK]={0,14,13,12,11,10,9,8,7,6,5,4,3,2,1,15};

int main(int argc, char *argv[])
{
  int		i;
  unsigned char Buffer[SEC_SIZE*SEC_PER_TRACK];
  
  while (read(0,Buffer,sizeof(Buffer))==sizeof(Buffer))
    for (i=0;i<SEC_PER_TRACK;i++)
      write(1,Buffer+table[i]*SEC_SIZE,SEC_SIZE);
  exit(0);
}
