/*

  P-Code interpreter (to run the apple pascal system)
  Copyright (C) 2000 Mario Klebsch

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  $Log: UnitIo.c,v $
  Revision 1.7  2001/08/01 19:27:03  mario
  Tippfehler korrigiert

  Revision 1.6  2001/06/16 17:21:42  mario
  Eine fehlende Abh�ngigkeit vom Pr�prozessorsymbol TURTLEGRAPHICS
  nachgetragen.

  Revision 1.5  2001/05/23 21:16:41  mario
  Turtlegraphics wurde als eigener Prozess ausgelagert.

  Revision 1.4  2001/05/21 19:06:48  mario
  Mode-Parameter bei den Disk-IO-Routinen entfernt

  Revision 1.3  2001/05/20 20:14:40  mario
  Neues Ger�t PRINTER: implementiert

  Revision 1.2  2001/05/20 13:12:02  mario
  CVS-Idents und Logs eingef�gt


*/

#ident "$Id: UnitIo.c,v 1.7 2001/08/01 19:27:03 mario Exp $";

#include <stdio.h>

#include "psystem.h"
#include "Memory.h"

#include "Diskio.h"
#include "Term.h"

void IoError(word Result)
{
  MemWr(IORSLT, Result);
}

void UnitRead(word Unit, word Addr, Integer AddrOffset,
	      word Len, word Block, word Mode)
{
  IoError(0);
  switch(Unit)
    {
    case 1:
    case 2:
      while (Len--)
	{
	  char ch=TermRead();
	  if (Unit==1)
	    TermWrite(ch, 0);
	  MemWrByte(Addr, AddrOffset++, ch);
	}
      break;
    case 4:
    case 5:
    case 9:
    case 10:
    case 11:
    case 12:
      DiskRead(Unit, Addr, AddrOffset, Len, Block);
      break;
    default:
      IoError(2);
      break;
    }
}

void PrinterWrite(byte ch, word Mode);

void UnitWrite(word Unit, word Addr, Integer AddrOffset,
	       word Len, word Block, word Mode)
{
  IoError(0);
  switch(Unit)
    {
    case 1:
    case 2:
      while (Len--)
	TermWrite(MemRdByte(Addr, AddrOffset++), Mode);
      break;
    case 4:
    case 5:
    case 9:
    case 10:
    case 11:
    case 12:
      DiskWrite(Unit, Addr, AddrOffset, Len, Block);
      break;
    case 6:
      while (Len--)
	PrinterWrite(MemRdByte(Addr, AddrOffset++), Mode);
      break;
    default:
      IoError(2);
      break;
    }
}

void PrinterClear(void);
void GraphicsClear(void);

void UnitClear(word Unit)
{
  IoError(0);
  switch(Unit)
    {
    case 1:
    case 2:
      break;
    case 4:
    case 5:
    case 11:
    case 12:
      DiskClear(Unit);
      break;
    case 3:
      PrinterClear();
#ifdef TURTLEGRAPHICS
      GraphicsClear();
#endif
      break;
    case 6:
      PrinterClear();
      break;
    default:
      IoError(9);
      break;
    }
}

void UnitStat(word Unit, word Addr, Integer Offset, word Dummy)
{
  IoError(0);
  switch(Unit)
    {
    case 1:
    case 2:
      MemWr(Addr, TermStat());
      break;
    case 4:
    case 5:
    case 11:
    case 12:
      DiskStat(Unit);
      break;
    default:
      IoError(9);
      break;
    }
}

word UnitBusy(word Unit)
{
  IoError(0);
  return(0);
}

void UnitWait(word Unit)
{
  IoError(0);
}
