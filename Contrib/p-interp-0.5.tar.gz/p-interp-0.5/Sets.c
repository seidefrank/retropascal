/*

  P-Code interpreter (to run the apple pascal system)
  Copyright (C) 2000 Mario Klebsch

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  $Log: Sets.c,v $
  Revision 1.2  2001/05/20 13:12:02  mario
  CVS-Idents und Logs eingef�gt


*/

#ident "$Id: Sets.c,v 1.2 2001/05/20 13:12:02 mario Exp $";

#include "psystem.h"
#include "Sets.h"

void SetPop(Set_t *Set)
{
  int	i;

  Set->Size=Pop();
  for (i=0;i<Set->Size;i++)
    Set->Data[i]=Pop();
}

void SetAdj(Set_t *Set, word Size)
{
  int i;
  for (i=Set->Size; i<Size; i++)
    Set->Data[i]=0;
  Set->Size=Size;
}

void SetPush(Set_t *Set)
{
  int i;
  for (i=Set->Size;i;i--)
    Push(Set->Data[i-1]);
  Push(Set->Size);
}

/* Set-Compare: return 0 if Set1==Set2, 1 if Set1!=Set2 */

int SetCmp(Set_t *Set1, Set_t *Set2)
{
  int	Size= (Set1->Size>Set2->Size) ? Set1->Size : Set2->Size;
  int	i;

  if (Set1->Size < Size)
    SetAdj(Set1, Size);
  if (Set2->Size < Size )
    SetAdj(Set2, Size);

  for (i=0;i<Size; i++)
    if (Set1->Data[i]!=Set2->Data[i])
      return(1);
  return(0);
}

/* returns 1 if SS is subset of S */

int SetIsSubset(Set_t *S, Set_t *SS)
{
  int	Size=SS->Size;
  int	i;

  if (S->Size < Size)
    SetAdj(S, Size);

  for (i=0; i<Size; i++)
    if  ( (S->Data[i]&SS->Data[i]) != SS->Data[i] )
      return(0);
  return(1);
}

