/*

  P-Code interpreter (to run the apple pascal system)
  Copyright (C) 2000 Mario Klebsch

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  $Log: Stack.c,v $
  Revision 1.2  2001/05/20 13:12:02  mario
  CVS-Idents und Logs eingef�gt


*/

#ident "$Id: Stack.c,v 1.2 2001/05/20 13:12:02 mario Exp $";

#include <stdio.h>
#include <assert.h>

#include "psystem.h"
#include "Memory.h"
#include "Stack.h"

extern word Sp;

word Pop(void)
{
  word	ret=MemRd(Sp);
  Sp = WordIndexed(Sp, 1);
  if (Sp>SP_TOP)
    panic("Stack underflow");
  return(ret);
}

Integer PopInteger(void)
{
  word w=Pop();

  if (w&0x8000)
    return(w-0x10000);
  else
    return(w);
}

float PopReal(void)
{
  word Buffer[2];

  assert (sizeof(word)==2);
  Buffer[0]=Pop();
  Buffer[1]=Pop();
  return(*(float*)Buffer);
}

void Push(word Value)
{
  Sp = WordIndexed(Sp, -1);
  MemWr(Sp, Value);
}

void PushReal(float Value)
{
  word	*Buffer=(word*)&Value;
  assert (sizeof(word)==2);
  Push(Buffer[1]);
  Push(Buffer[0]);
}
