/*

  P-Code interpreter (to run the apple pascal system)
  Copyright (C) 2000 Mario Klebsch

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

  $Log: Array.c,v $
  Revision 1.2  2001/05/20 13:12:02  mario
  CVS-Idents und Logs eingef�gt


*/

#ident "$Id: Array.c,v 1.2 2001/05/20 13:12:02 mario Exp $";

#include <stdio.h>

#include "psystem.h"
#include "Memory.h"
#include "Array.h"

/* String-Compare: returns -1 if S1<S2, 0 if S1==S2, 1 if S1>S2 */

int StrCmp(word s1, word s2)
{
  byte	Len1 = MemRdByte(s1, 0);
  byte	Len2 = MemRdByte(s2, 0);
  byte	Len  = Len1<Len2?Len1:Len2;	/* Length to compare */
  byte	i;

  for (i=0;i<Len; i++)
    {
      byte	Ch1=MemRdByte(s1, i+1);	/* Get a char from both strings	    */
      byte	Ch2=MemRdByte(s2, i+1);
      if (Ch1<Ch2)
	return(-1);			/* S1<S2			    */
      else if (Ch1>Ch2)
	return(1);			/* S1>S2			    */
    }
					/* all chars in range of common	    */
					/* length are equal.		    */
  if (Len1<Len2)			/* S1 ist shorter?		    */
    return(-1);				/* so S1<S2			    */
  else if (Len1>Len2)			/* S2 is shorter?		    */
    return(1);				/* so S1>S2			    */
  else					/* both strings have the same	    */
    return(0);				/* length, so they are equal.	    */
} /* StrCmp() */

/* ByteArray-Compare: returns -1 if BA1<BA2, 0 if BA1==BA2, 1 if BA1>BA2 */

int ByteCmp(word ba1, word ba2, word Len)
{
  word	i;

  for (i=0;i<Len; i++)
    {
      byte	Ch1=MemRdByte(ba1, i);	/* Get a char from both strings	    */
      byte	Ch2=MemRdByte(ba2, i);
      if (Ch1<Ch2)
	return(-1);			/* BA1<BA2			    */
      else if (Ch1>Ch2)
	return(1);			/* BA1>BA2			    */
    }
  return(0);
}

/* WordArray-Compare: return 0 if WA1==WA2, 1 if WA1!=WA2 */

int WordCmp(word wa1, word wa2, word Len)
{
  word	i;
  for (i=0;i<Len; i++)
    if (MemRd(WordIndexed(wa1,i)) !=
	MemRd(WordIndexed(wa2,i)) )
      return(1);
  return(0);
}

